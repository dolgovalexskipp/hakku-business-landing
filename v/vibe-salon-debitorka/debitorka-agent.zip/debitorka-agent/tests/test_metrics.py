"""Hand-made dataset: 6 invoices / 4 payments — checks bucket, cohort and KPI formulas by numbers."""
import pandas as pd
import pytest
from debitorka.schema import Dataset
from debitorka import metrics as M
from debitorka.config import load_config
from debitorka.sources.synthetic import SyntheticSource


def ds():
    inv = pd.DataFrame([
        # id, client, issue, amount
        ("i1", "c1", "2026-05-31", 1000),   # paid in full on time
        ("i2", "c2", "2026-05-31", 2000),   # paid half late (11–60 on 2026-07-15)
        ("i3", "c3", "2026-05-31", 3000),   # never paid → age on 2026-07-15 = 43 d → 11–60
        ("i4", "c4", "2026-03-31", 4000),   # never paid → 104 d → 90+
        ("i5", "c5", "2026-04-30", 5000),   # paid after control date → not "in time"
        ("i6", "c1", "2026-06-30", 600),    # issued 30.06, due 02.07, paid 05.07 → 13 days late, but paid → no residual
    ], columns=["invoice_id", "client_id", "issue_date", "amount"])
    inv["client_name"] = inv.client_id.map(lambda c: "ООО " + c.upper())
    inv["contract_id"] = "ctr_" + inv.client_id
    inv["issue_date"] = pd.to_datetime(inv.issue_date)
    inv["due_date"] = inv.issue_date + pd.Timedelta(days=2)
    pay = pd.DataFrame([
        ("p1", "i1", "c1", "2026-06-03", 1000),
        ("p2", "i2", "c2", "2026-06-20", 1000),
        ("p3", "i5", "c5", "2026-06-10", 5000),   # control date for April = 01.06 → paid after
        ("p4", "i6", "c1", "2026-07-05", 600),
    ], columns=["payment_id", "invoice_id", "client_id", "pay_date", "amount"])
    ctr = pd.DataFrame({"contract_id": ["ctr_c1", "ctr_c2", "ctr_c3", "ctr_c4", "ctr_c5"],
                        "client_id": ["c1", "c2", "c3", "c4", "c5"], "start_date": "2025-01-01",
                        "status": ["active", "active", "suspended", "terminated", "active"],
                        "status_date": ["2025-01-01", "2025-01-01", "2026-07-10", "2026-05-01", "2025-01-01"],
                        "suspend_reason": [None, None, "lost", None, None]})
    return Dataset(inv, pay, ctr).validate()


AS_OF = pd.Timestamp("2026-07-15")


def test_aging_buckets():
    b = M.aging_buckets(ds(), AS_OF).set_index("bucket")
    assert b.loc["11–60", "amount"] == 1000 + 3000        # i2 residual + i3
    assert b.loc["11–60", "invoices"] == 2
    assert b.loc["90+", "amount"] == 4000                 # i4
    assert b.loc["0–10", "amount"] == 0
    assert b.loc["Итого", "amount"] == 8000


def test_collection_table_and_kpi():
    t = M.collection_table(ds(), AS_OF).set_index("month")
    # May: billed 6000; in time (by 01.07): i1 1000 + i2 1000 = 2000 → 33.3 %; total by 15.07 same
    assert t.loc["2026-05", "pct_in_time"] == pytest.approx(33.3)
    # April: i5 5000 paid 10.06, control 01.06 → 0 % in time, 100 % total
    assert t.loc["2026-04", "pct_in_time"] == 0
    assert t.loc["2026-04", "pct_total"] == 100
    kpi = M.kpi_paid_after_month(ds(), AS_OF)
    assert list(kpi.month) == ["2026-03", "2026-04", "2026-05"]   # June's control date (01.08) not reached


def test_cohort_curve():
    c = M.cohort_curve(ds(), "2026-05", AS_OF)
    # week1 cutoff 07.06: i1 paid 03.06 → 1000/6000 = 16.7; week3 cutoff 21.06: +1000 → 33.3
    assert c[c.week == 1].pct.iloc[0] == pytest.approx(16.7)
    assert c[c.week == 3].pct.iloc[0] == pytest.approx(33.3)
    assert c.delta_pp.iloc[2] == pytest.approx(16.6, abs=0.2)


def test_stuck_and_suspensions():
    s = M.stuck_clients(ds(), AS_OF)
    assert list(s.client_id) == ["c4"]
    assert s.contract_status.iloc[0] == "terminated"
    sw, base = M.suspensions_weekly(ds(), AS_OF, weeks=4)
    assert base["last"] == 1 and sw.lost.iloc[-1] == 1


def test_synthetic_calibration():
    """Synthetic data must land in the customer's real corridor (Dec'25–May'26 reference)."""
    cfg = load_config()
    d = SyntheticSource(cfg).load()
    as_of = pd.Timestamp("2026-08-17")
    t = M.collection_table(d, as_of)
    closed = t[(t.month != "Итого") & t.control_reached]
    assert 330 - 30 <= closed.invoices.min() and closed.invoices.max() <= 360 + 30
    assert 2.0e6 <= closed.billed.min() and closed.billed.max() <= 3.3e6
    assert 62 <= closed.pct_in_time.min() and closed.pct_in_time.max() <= 84, closed.pct_in_time.tolist()
    assert 68 <= closed.pct_total.min() and closed.pct_total.max() <= 92, closed.pct_total.tolist()
    assert 70 <= t[t.month == "Итого"].pct_in_time.iloc[0] <= 80
