# Дебиторка — агент мониторинга и алертинга

MVP, собранный на вайб-салоне Hakku | бИИзнес 19.08.2026 для бухгалтерской аутсорс-компании (400+ клиентов, 1С:УФА).
Задача: руководитель узнаёт об отклонениях по дебиторке из мессенджера, а не копаясь в отчётах 1С.

```
[1С:УФА] --(сейчас: выгрузка xlsx | потом: OData)--> sources/ --> Dataset(invoices, payments, contracts)
                                                                      |
                                                   metrics.py  бакеты 0–10/11–60/61–90/90+, когорта, KPI, приостановки, зависшие
                                                   rules.py    пороги из config.yaml → алерты
                                                                      |
                              +---------------------------------------+---------------------------------------+
                              |                                       |                                       |
                    notify/telegram.py                        narrator.py (LLM)                        dashboard/app.py
                    алерт сразу (Max — тот же интерфейс)      дайджест + Q&A по агрегатам             витрина руководителя (Streamlit)
                                                              видит ТОЛЬКО псевдонимы client_XXXX
```

## Запуск за 3 команды

```bash
python3.11 -m debitorka backfill --from 2026-06-08 --to 2026-08-10        # недельные срезы задним числом
python3.11 -m debitorka run --as-of 2026-08-17 --notify console --digest   # алерты + LLM-дайджест (telegram — при токене в .env)
python3.11 -m streamlit run dashboard/app.py                               # витрина
```
Перед первым запуском: `cp .env.example .env` и заполнить (см. ниже). Зависимости — `requirements.txt`.
Модуль запускается из корня репо (`PYTHONPATH=src` или `pip install -e .`).

Ещё: `python3.11 -m debitorka collection --as-of 2026-08-17` — таблица собираемости; `python3.11 -m debitorka ask "кто в 90+ дольше всех?" --as-of 2026-08-17`; `python3.11 -m pytest`.

## Как подставить свою выгрузку из 1С

1. Положить в `data/import/` два файла: «Реализация за период» (`realizaciya.xlsx`: Номер, Дата, Контрагент, Договор, Сумма, Оплачено, Дата оплаты) и статусы договоров (`dogovory.xlsx`: Договор, Контрагент, Дата начала, Статус, Дата статуса, Причина).
2. Если колонки называются иначе — поправить `config.yaml → excel_1c.columns`.
3. `python3.11 -m debitorka run --as-of <дата> --source excel`.
Контракт данных и откуда что брать в 1С — `docs/data_contract.md`.

## Что уходит в LLM, а что нет

- Уходит: JSON агрегатов (суммы по бакетам, проценты когорт, число приостановок) и список алертов, где клиенты — `client_0042`.
- Не уходит: названия контрагентов, реквизиты, построчные счета. Маппинг псевдонимов живёт в `data/import/_aliases.csv` и используется только витриной / флагом `--real-names`.
- Каждый запрос и ответ логируется в `logs/llm/*.json` — можно открыть и убедиться.
- LLM не считает метрики и не решает, что алертить — это детерминированный код с тестами. Нет ключа / прокси лёг — пайплайн отдаёт шаблонный дайджест и не падает.

## .env

```
TELEGRAM_BOT_TOKEN=   # от @BotFather
TELEGRAM_CHAT_ID=     # написать боту /start, затем взять chat.id из getUpdates
LLM_BASE_URL=         # OpenAI-совместимый endpoint
LLM_MODEL=gemini-3.5-flash
GEMINI_API_KEY=
```

## Структура

`src/debitorka/` — schema, sources/ (synthetic, excel_1c, odata_1c-stub), metrics, rules, narrator, notify/, pipeline, cli ·
`dashboard/app.py` · `tests/` · `docs/` (data_contract, decisions, next) · `config.yaml` (пороги, синтетика, маппинг колонок).
