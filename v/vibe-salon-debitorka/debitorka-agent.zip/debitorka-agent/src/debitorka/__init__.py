"""Debitorka agent — receivables monitoring & alerting MVP."""
__version__ = "0.1.0"
