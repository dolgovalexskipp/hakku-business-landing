"""Receivables metrics — pure pandas functions. Formulas mirror the customer's Excel tracker.

All functions take a Dataset and an `as_of` date (snapshot date) and return DataFrames/dicts.
LLM is never involved here.
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from .schema import Dataset

BUCKET_LABELS = ["0–10", "11–60", "61–90", "90+"]


def _bucket(age_days: pd.Series) -> pd.Series:
    return pd.cut(age_days, bins=[-0.5, 10.5, 60.5, 90.5, np.inf], labels=BUCKET_LABELS)


def paid_by(ds: Dataset, cutoff: pd.Timestamp) -> pd.Series:
    """Sum of payments per invoice with pay_date <= cutoff (indexed by invoice_id)."""
    p = ds.payments[ds.payments.pay_date <= cutoff]
    return p.groupby("invoice_id")["amount"].sum()


def residuals(ds: Dataset, as_of: pd.Timestamp) -> pd.DataFrame:
    """Per-invoice residual and overdue age on the snapshot date."""
    inv = ds.invoices[ds.invoices.issue_date <= as_of].copy()
    inv["paid"] = inv.invoice_id.map(paid_by(ds, as_of)).fillna(0.0)
    inv["residual"] = (inv.amount - inv.paid).round(2)
    inv["age_days"] = (as_of - inv.due_date).dt.days
    return inv


def aging_buckets(ds: Dataset, as_of: pd.Timestamp) -> pd.DataFrame:
    """Просроченная дебиторка по срокам на дату среза (лист «Дебиторка по срокам»).

    Остаток = сумма − оплачено до даты среза; возраст = дата среза − срок оплаты.
    Бакеты 0–10 / 11–60 / 61–90 / 90+ дней. Снимок, не история одного долга.
    """
    r = residuals(ds, as_of)
    od = r[(r.residual > 0.5) & (r.age_days >= 0)].copy()
    od["bucket"] = _bucket(od.age_days)
    g = od.groupby("bucket", observed=False).agg(amount=("residual", "sum"), invoices=("invoice_id", "count"),
                                                  clients=("client_id", "nunique"))
    g = g.reindex(BUCKET_LABELS).fillna(0)
    g.loc["Итого"] = [od.residual.sum(), len(od), od.client_id.nunique()]
    g["amount"] = g.amount.round(0)
    g[["invoices", "clients"]] = g[["invoices", "clients"]].astype(int)
    g.index.name = "bucket"
    return g.reset_index()


def aging_delta(prev: pd.DataFrame, cur: pd.DataFrame) -> pd.DataFrame:
    """Δ ₽ и Δ % по каждому бакету и итогу к предыдущему срезу."""
    m = cur.merge(prev[["bucket", "amount"]].rename(columns={"amount": "prev_amount"}), on="bucket", how="left")
    m["delta_rub"] = (m.amount - m.prev_amount).round(0)
    m["delta_pct"] = np.where(m.prev_amount > 0, (m.delta_rub / m.prev_amount * 100).round(1), np.nan)
    return m


def collection_table(ds: Dataset, as_of: pd.Timestamp) -> pd.DataFrame:
    """«Собираемость по счетам» — воспроизводит таблицу заказчицы.

    По каждому месяцу выставления: кол-во счетов, выставлено, оплачено «в срок»
    (до 1-го числа месяца+2 — счёт 31.12 → оплаты за январь, срез 01.02), % в срок,
    оплачено всего на дату среза, % всего. Плюс строка «Итого».
    """
    inv = ds.invoices[ds.invoices.issue_date <= as_of].copy()
    inv["month"] = inv.issue_date.dt.to_period("M")
    paid_total = paid_by(ds, as_of)
    rows = []
    for month, g in inv.groupby("month"):
        control = (month + 2).to_timestamp()  # 1st day of month+2
        pt = paid_by(ds, min(control, as_of + pd.Timedelta(days=1)) - pd.Timedelta(seconds=1))
        billed = g.amount.sum()
        in_time = g.invoice_id.map(pt).fillna(0).clip(upper=g.amount).sum()
        total = g.invoice_id.map(paid_total).fillna(0).clip(upper=g.amount).sum()
        rows.append({"month": str(month), "invoices": len(g), "billed": round(billed),
                     "paid_in_time": round(in_time), "pct_in_time": round(in_time / billed * 100, 1),
                     "paid_total": round(total), "pct_total": round(total / billed * 100, 1),
                     "control_date": control.date().isoformat(), "control_reached": bool(control <= as_of)})
    df = pd.DataFrame(rows)
    tot = {"month": "Итого", "invoices": df.invoices.sum(), "billed": df.billed.sum(),
           "paid_in_time": df.paid_in_time.sum(), "paid_total": df.paid_total.sum(),
           "control_date": "", "control_reached": True}
    tot["pct_in_time"] = round(tot["paid_in_time"] / tot["billed"] * 100, 1)
    tot["pct_total"] = round(tot["paid_total"] / tot["billed"] * 100, 1)
    return pd.concat([df, pd.DataFrame([tot])], ignore_index=True)


def cohort_curve(ds: Dataset, cohort_month: str, as_of: pd.Timestamp, weeks: int = 8) -> pd.DataFrame:
    """Кривая инкассации (лист «Когорта по месяцам»): фиксированный список счетов одного
    месяца реализации, % оплачено ПО СУММЕ на каждую неделю после конца месяца, Δ п.п.
    """
    month = pd.Period(cohort_month, "M")
    g = ds.invoices[ds.invoices.issue_date.dt.to_period("M") == month]
    billed = g.amount.sum()
    month_end = month.to_timestamp(how="end").normalize()
    rows = []
    for w in range(1, weeks + 1):
        cutoff = month_end + pd.Timedelta(days=7 * w)
        if cutoff > as_of:
            break
        paid = g.invoice_id.map(paid_by(ds, cutoff)).fillna(0).clip(upper=g.amount).sum()
        rows.append({"cohort": str(month), "week": w, "cutoff": cutoff.date().isoformat(),
                     "billed": round(billed), "paid": round(paid), "pct": round(paid / billed * 100, 1) if billed else np.nan})
    df = pd.DataFrame(rows)
    if len(df):
        df["delta_pp"] = df.pct.diff().round(1)
    return df


def cohort_norms(ds: Dataset, as_of: pd.Timestamp, exclude_month: str, weeks: int = 8) -> pd.Series:
    """Медианный % оплаты по неделе N по всем предыдущим когортам (норма для алерта)."""
    months = sorted(ds.invoices.issue_date.dt.to_period("M").unique())
    parts = [cohort_curve(ds, str(m), as_of, weeks) for m in months if str(m) != exclude_month]
    parts = [p for p in parts if len(p)]
    if not parts:
        return pd.Series(dtype=float)
    return pd.concat(parts).groupby("week")["pct"].median()


def kpi_paid_after_month(ds: Dataset, as_of: pd.Timestamp) -> pd.DataFrame:
    """KPI «% оплаты через месяц после выставления» (лист «KPI — оплата через месяц»):
    контрольная точка = 1-е число месяца+2, по сумме. Одна строка на закрытую когорту.
    """
    t = collection_table(ds, as_of)
    t = t[(t.month != "Итого") & (t.control_reached)].copy()
    t["delta_pp"] = t.pct_in_time.diff().round(1)
    return t[["month", "billed", "control_date", "paid_in_time", "pct_in_time", "delta_pp"]]


def suspensions_weekly(ds: Dataset, as_of: pd.Timestamp, weeks: int = 12) -> tuple[pd.DataFrame, dict]:
    """Приостановки по неделям с разбивкой по причине (чек-лист п.7) + baseline по прошлым неделям."""
    c = ds.contracts[(ds.contracts.status == "suspended") & (ds.contracts.status_date <= as_of)]
    rows = []
    for w in range(weeks - 1, -1, -1):
        end = as_of - pd.Timedelta(days=7 * w)
        start = end - pd.Timedelta(days=7)
        g = c[(c.status_date > start) & (c.status_date <= end)]
        rows.append({"week_end": end.date().isoformat(), "total": len(g),
                     "lost": int((g.suspend_reason == "lost").sum()), "dispute": int((g.suspend_reason == "dispute").sum()),
                     "pause": int((g.suspend_reason == "pause").sum())})
    df = pd.DataFrame(rows)
    hist = df.total.iloc[:-1]
    base = {"mean": float(hist.mean()) if len(hist) else 0.0, "sd": float(hist.std(ddof=0)) if len(hist) > 1 else 0.0,
            "last": int(df.total.iloc[-1])}
    return df, base


def stuck_clients(ds: Dataset, as_of: pd.Timestamp, min_age_days: int = 61) -> pd.DataFrame:
    """Зависшие клиенты: остаток в 61–90 / 90+ (чек-лист п.4/5), статус договора, макс. возраст долга."""
    r = residuals(ds, as_of)
    od = r[(r.residual > 0.5) & (r.age_days >= min_age_days)]
    if od.empty:
        return pd.DataFrame(columns=["client_id", "client_name", "amount", "max_age_days", "invoices", "contract_status"])
    g = od.groupby("client_id").agg(client_name=("client_name", "first"), amount=("residual", "sum"),
                                    max_age_days=("age_days", "max"), invoices=("invoice_id", "count")).reset_index()
    st = ds.contracts.drop_duplicates("client_id").set_index("client_id")["status"]
    g["contract_status"] = g.client_id.map(st).fillna("active")
    g["amount"] = g.amount.round(0)
    return g.sort_values(["max_age_days", "amount"], ascending=False).reset_index(drop=True)


def entered_bucket(ds: Dataset, as_of: pd.Timestamp, min_age: int = 91, days: int = 7) -> pd.DataFrame:
    """Счета, пересёкшие границу бакета (по умолчанию 90 дней) за последние `days` дней, сгруппированные по клиенту."""
    r = residuals(ds, as_of)
    hit = r[(r.residual > 0.5) & (r.age_days >= min_age) & (r.age_days < min_age + days)]
    if hit.empty:
        return pd.DataFrame(columns=["client_id", "client_name", "amount", "max_age_days", "invoices", "contract_status"])
    g = hit.groupby("client_id").agg(client_name=("client_name", "first"), amount=("residual", "sum"),
                                     max_age_days=("age_days", "max"), invoices=("invoice_id", "count")).reset_index()
    st = ds.contracts.drop_duplicates("client_id").set_index("client_id")["status"]
    g["contract_status"] = g.client_id.map(st).fillna("active")
    g["amount"] = g.amount.round(0)
    return g.sort_values("amount", ascending=False).reset_index(drop=True)


def unpaid(ds: Dataset, as_of: pd.Timestamp, since: pd.Timestamp | None = None, month: str | None = None) -> pd.DataFrame:
    """Неоплаченные счета за месяц / с начала года (чек-лист п.4, п.5)."""
    r = residuals(ds, as_of)
    r = r[r.residual > 0.5]
    if month:
        r = r[r.issue_date.dt.to_period("M") == pd.Period(month, "M")]
    if since is not None:
        r = r[r.issue_date >= since]
    return r[["invoice_id", "client_id", "client_name", "issue_date", "amount", "paid", "residual", "age_days"]] \
        .sort_values("age_days", ascending=False).reset_index(drop=True)


def summary(ds: Dataset, as_of: pd.Timestamp) -> dict:
    """Compact aggregate bundle (pseudonymous) — the ONLY thing that goes to the LLM."""
    prev = as_of - pd.Timedelta(days=7)
    cur_b, prev_b = aging_buckets(ds, as_of), aging_buckets(ds, prev)
    d = aging_delta(prev_b, cur_b).set_index("bucket")
    dm = aging_delta(aging_buckets(ds, as_of - pd.Timedelta(days=28)), cur_b).set_index("bucket")
    months = sorted(ds.invoices[ds.invoices.issue_date <= as_of].issue_date.dt.to_period("M").unique())
    last_month = str(months[-1]) if months else None
    # "last cohort" = the most recent month whose invoices are at least one week old
    cohort_month = next((str(m) for m in reversed(months)
                         if m.to_timestamp(how="end") + pd.Timedelta(days=7) <= as_of), None)
    cc = cohort_curve(ds, cohort_month, as_of) if cohort_month else pd.DataFrame()
    norms = cohort_norms(ds, as_of, cohort_month) if cohort_month else pd.Series(dtype=float)
    kpi = kpi_paid_after_month(ds, as_of)
    sw, base = suspensions_weekly(ds, as_of)
    stuck = stuck_clients(ds, as_of)
    ent = entered_bucket(ds, as_of, 91, 7)
    return {
        "entered_90plus_week": [{"client_id": r.client_id, "amount": float(r.amount), "max_age_days": int(r.max_age_days),
                                 "invoices": int(r.invoices), "contract_status": r.contract_status} for r in ent.itertuples()],
        "as_of": as_of.date().isoformat(),
        "overdue": {b: {"amount": float(d.loc[b, "amount"]), "invoices": int(d.loc[b, "invoices"]),
                        "clients": int(d.loc[b, "clients"]), "delta_rub": float(d.loc[b, "delta_rub"]),
                        "delta_pct": None if pd.isna(d.loc[b, "delta_pct"]) else float(d.loc[b, "delta_pct"]),
                        "delta_28d_rub": float(dm.loc[b, "delta_rub"]),
                        "delta_28d_pct": None if pd.isna(dm.loc[b, "delta_pct"]) else float(dm.loc[b, "delta_pct"])}
                    for b in d.index},
        "note": "delta_pct — к прошлой неделе; delta_28d_pct — к тому же дню прошлого месяца. Счета выставляются "
                "последним днём месяца, поэтому недельная Δ бакетов 0–10 / 11–60 отражает цикл биллинга.",
        "cohort_last": ({"month": cohort_month, "week": int(cc.week.iloc[-1]), "pct": float(cc.pct.iloc[-1]),
                         "norm_pct": None if cc.week.iloc[-1] not in norms.index else float(norms.loc[cc.week.iloc[-1]])}
                        if len(cc) else None),
        "kpi_last_closed": ({"month": kpi.month.iloc[-1], "pct": float(kpi.pct_in_time.iloc[-1]),
                             "control_date": kpi.control_date.iloc[-1]} if len(kpi) else None),
        "suspensions": {"last_week": base["last"], "baseline_mean": round(base["mean"], 1), "baseline_sd": round(base["sd"], 1),
                        "by_reason_last_week": {k: int(sw[k].iloc[-1]) for k in ("lost", "dispute", "pause")}},
        "stuck_clients_count": int(len(stuck)),
        "stuck_top": [{"client_id": r.client_id, "amount": float(r.amount), "max_age_days": int(r.max_age_days),
                       "contract_status": r.contract_status} for r in stuck.head(10).itertuples()],
        "last_month": last_month,
    }
