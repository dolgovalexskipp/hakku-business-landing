import argparse
import pandas as pd


def main() -> None:
    p = argparse.ArgumentParser(prog="debitorka", description="Receivables monitoring & alerting")
    sub = p.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("run", help="weekly snapshot + alerts")
    r.add_argument("--as-of", required=True)
    r.add_argument("--source", default="synthetic", choices=["synthetic", "excel", "odata"])
    r.add_argument("--notify", default="console", choices=["console", "telegram", "max"])
    r.add_argument("--digest", action="store_true", help="also send the LLM weekly digest")
    r.add_argument("--real-names", action="store_true", help="show real client names in the message (local use only)")
    b = sub.add_parser("backfill", help="compute weekly snapshots for a date range")
    b.add_argument("--from", dest="start", required=True); b.add_argument("--to", dest="end", required=True)
    b.add_argument("--every", default="7d"); b.add_argument("--source", default="synthetic")
    a = sub.add_parser("ask", help="ask the narrator a question over aggregates")
    a.add_argument("question"); a.add_argument("--as-of", required=True); a.add_argument("--source", default="synthetic")
    c = sub.add_parser("collection", help="print the collection table (как у заказчицы)")
    c.add_argument("--as-of", required=True); c.add_argument("--source", default="synthetic")
    args = p.parse_args()

    from . import pipeline, metrics as M
    if args.cmd == "run":
        pipeline.run(args.as_of, args.source, args.notify, args.digest, args.real_names)
    elif args.cmd == "backfill":
        pipeline.backfill(args.start, args.end, int(args.every.rstrip("d")), args.source)
    elif args.cmd == "ask":
        from . import narrator
        ds = pipeline.load_dataset(args.source, pipeline.load_config(), pd.Timestamp(args.as_of))
        print(narrator.ask(args.question, M.summary(ds, pd.Timestamp(args.as_of))))
    elif args.cmd == "collection":
        ds = pipeline.load_dataset(args.source, pipeline.load_config(), pd.Timestamp(args.as_of))
        pd.set_option("display.width", 200)
        print(M.collection_table(ds, pd.Timestamp(args.as_of)).to_string(index=False))


if __name__ == "__main__":
    main()
