"""LLM narrator — turns alerts + aggregates into a human digest; answers questions over aggregates.

Goes through the own OpenAI-compatible proxy (LLM_BASE_URL / LLM_MODEL / GEMINI_API_KEY).
ONLY pseudonymous aggregates are sent. Every prompt/response is logged to logs/llm/.
Falls back to a deterministic template if the key is missing or the proxy times out.
"""
from __future__ import annotations
import json
import os
import time
from datetime import datetime
from .config import LOGS
from .rules import Alert, ICON

SYSTEM = (
    "Ты — финансовый ассистент руководителя компании бухгалтерского аутсорсинга (400+ клиентов, счета "
    "выставляются последним днём месяца, срок оплаты 2 дня). Тебе дают JSON с агрегатами по дебиторке и "
    "список алертов. Клиенты обозначены псевдонимами client_XXXX — используй их как есть. Пиши по-русски, "
    "коротко, без воды и без вводных фраз. Структура: 1) самое тревожное (1–3 пункта с цифрами), "
    "2) что стабильно (1–2 строки), 3) три конкретных действия на неделю: кому (руководитель/менеджеры) и что. "
    "Не придумывай цифр и клиентов, которых нет во входе. Не давай юридических советов. Объём — до 900 знаков. "
    "Важно: счета выставляются последним днём месяца, поэтому недельная динамика бакетов 0–10 и 11–60 — это "
    "цикл биллинга, а не тренд; для общей просрочки смотри поле delta_28d (к тому же дню прошлого месяца)."
)


def _client():
    key = os.environ.get("GEMINI_API_KEY")
    base = os.environ.get("LLM_BASE_URL")
    if not key or not base:
        return None, None
    from openai import OpenAI
    return OpenAI(base_url=base, api_key=key, timeout=30, max_retries=1), os.environ.get("LLM_MODEL", "gemini-3.5-flash")


def _log(kind: str, payload: dict) -> None:
    d = LOGS / "llm"
    d.mkdir(parents=True, exist_ok=True)
    (d / f"{datetime.now():%Y%m%d_%H%M%S}_{kind}.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def _chat(kind: str, user: str, max_tokens: int = 2000) -> str | None:
    client, model = _client()
    if client is None:
        return None
    t0 = time.time()
    try:
        # thinking model: without reasoning_effort=none the "thoughts" eat max_tokens and the text is cut
        r = client.chat.completions.create(model=model, max_tokens=max_tokens,
                                           extra_body={"reasoning_effort": "none"},
                                           messages=[{"role": "system", "content": SYSTEM}, {"role": "user", "content": user}])
        text = r.choices[0].message.content.strip()
        _log(kind, {"model": model, "system": SYSTEM, "user": user, "response": text, "seconds": round(time.time() - t0, 1)})
        return text
    except Exception as e:  # proxy down / timeout → fallback, pipeline never dies
        _log(kind + "_error", {"model": model, "user": user, "error": repr(e)})
        print(f"[narrator] LLM unavailable ({type(e).__name__}) — using template fallback")
        return None


def weekly_digest(alerts: list[Alert], summary: dict) -> str:
    payload = {"as_of": summary["as_of"], "alerts": [a.to_dict() for a in alerts], "summary": summary}
    user = "Составь еженедельный дайджест по этим данным:\n" + json.dumps(payload, ensure_ascii=False)
    text = _chat("digest", user)
    return text if text else template_digest(alerts, summary)


def ask(question: str, summary: dict) -> str:
    user = f"Данные:\n{json.dumps(summary, ensure_ascii=False)}\n\nВопрос руководителя: {question}\nОтветь по данным, кратко."
    text = _chat("ask", user, max_tokens=800)
    return text if text else "LLM недоступна; вот агрегаты:\n" + json.dumps(summary, ensure_ascii=False, indent=1)


def template_digest(alerts: list[Alert], summary: dict) -> str:
    ov = summary["overdue"]["Итого"]
    lines = [f"Дайджест по дебиторке · {summary['as_of']} (шаблон, без LLM)"]
    if alerts:
        lines.append("Тревожное:")
        lines += [f"{ICON[a.level]} {a.title}" for a in alerts]
    else:
        lines.append("🟢 Отклонений нет.")
    d = ov["delta_pct"]
    lines.append("Итого просрочка " + f"{ov['amount']:,.0f} ₽".replace(",", " ") + (f" ({d:+.0f} % к неделе)" if d is not None else ""))
    c = summary.get("cohort_last")
    if c:
        lines.append(f"Когорта {c['month']}: {c['pct']:.0f} % на {c['week']}-й неделе" + (f" (норма {c['norm_pct']:.0f} %)" if c.get("norm_pct") else ""))
    lines.append("Действия: менеджерам — обзвон клиентов из списка 90+; руководителю — разобрать причины приостановок.")
    return "\n".join(lines)
