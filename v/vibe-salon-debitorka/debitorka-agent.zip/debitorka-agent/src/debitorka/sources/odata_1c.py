"""STUB — 1C OData adapter. Not implemented in this iteration (see docs/next.md).

What is needed from 1C (УФА / Бухгалтерия 3.0):
  * publish the infobase on a web server with OData enabled (standard interface oData),
  * a dedicated read-only user,
  * entities: Document_РеализацияТоваровУслуг (invoices), Document_ПоступлениеНаРасчетныйСчет +
    Document_ПоступлениеНаличных (payments, with document-of-settlement link),
    AccumulationRegister_РасчетыСКонтрагентами / УФА-specific catalog of contracts with statuses,
  * base URL like https://host/base/odata/standard.odata/<Entity>?$format=json&$filter=...
The adapter must return the same Dataset as Excel1CSource — nothing else in the system changes.
"""
from .base import Source
from ..schema import Dataset


class OData1CSource(Source):
    def load(self) -> Dataset:
        raise NotImplementedError("OData adapter is planned for the next iteration (docs/next.md)")
