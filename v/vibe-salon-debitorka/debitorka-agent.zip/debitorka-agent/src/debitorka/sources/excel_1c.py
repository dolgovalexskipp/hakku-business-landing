"""Loader for a 1C export (xlsx/csv) dropped into data/import/. Column mapping lives in config.yaml.

Expected files (names configurable):
  * realizaciya.xlsx — «Реализация за период»: Номер, Дата, Контрагент, Договор, Сумма, Оплачено, Дата оплаты
  * dogovory.xlsx    — статусы договоров: Договор, Контрагент, Дата начала, Статус, Дата статуса, Причина
If the realization file has only «Оплачено» (no per-payment rows), one payment per invoice is synthesized
with pay_date = «Дата оплаты» (or NaT → treated as unpaid until a date is known; see docs/decisions.md).
Client names are pseudonymised deterministically (client_XXXX); the mapping stays in data/import/_aliases.csv.
"""
from __future__ import annotations
import hashlib
import re
import pandas as pd
from .base import Source
from ..schema import Dataset
from ..config import DATA

IMPORT = DATA / "import"


def _read(path):
    if path.suffix.lower() in (".xlsx", ".xlsm", ".xls"):
        return pd.read_excel(path)
    return pd.read_csv(path, sep=None, engine="python")


def _num(s: pd.Series) -> pd.Series:
    return pd.to_numeric(s.astype(str).str.replace(" ", "").str.replace(" ", "").str.replace(",", "."), errors="coerce")


def _date(s: pd.Series) -> pd.Series:
    return pd.to_datetime(s, dayfirst=True, errors="coerce")


def pseudonym(name: str) -> str:
    h = hashlib.sha1(str(name).strip().lower().encode("utf-8")).hexdigest()
    return f"client_{int(h[:6], 16) % 10000:04d}"


class Excel1CSource(Source):
    def load(self) -> Dataset:
        e = self.cfg["excel_1c"]; terms = int(self.cfg.get("payment_terms_days", 2))
        inv_path = IMPORT / e["invoices_file"]
        if not inv_path.exists():
            cands = [p for p in IMPORT.iterdir() if p.suffix.lower() in (".xlsx", ".csv") and not p.name.startswith("_")]
            if not cands:
                raise FileNotFoundError(f"put the 1C export into {IMPORT}")
            inv_path = cands[0]
        raw = _read(inv_path)
        c = e["columns"]["invoices"]
        inv = pd.DataFrame({
            "invoice_id": raw[c["invoice_id"]].astype(str) if c["invoice_id"] in raw else [f"inv_{i:05d}" for i in range(1, len(raw) + 1)],
            "client_name": raw[c["client_name"]].astype(str).str.strip(),
            "contract_id": raw[c["contract_id"]].astype(str) if c.get("contract_id") in raw else "",
            "issue_date": _date(raw[c["issue_date"]]),
            "amount": _num(raw[c["amount"]]),
        }).dropna(subset=["issue_date", "amount"])
        inv["client_id"] = inv.client_name.map(pseudonym)
        inv["due_date"] = inv.issue_date + pd.Timedelta(days=terms)
        inv["invoice_id"] = inv.invoice_id.where(~inv.invoice_id.duplicated(), inv.invoice_id + "_" + inv.groupby("invoice_id").cumcount().astype(str))
        # payments
        pays = []
        paid = _num(raw[c["paid"]]) if c.get("paid") in raw else pd.Series(0.0, index=raw.index)
        pay_date = _date(raw[c["pay_date"]]) if c.get("pay_date") in raw else pd.Series(pd.NaT, index=raw.index)
        for i, (iid, cid, amt) in enumerate(zip(inv.invoice_id, inv.client_id, paid.loc[inv.index])):
            if pd.notna(amt) and amt > 0:
                pd_ = pay_date.loc[inv.index[i]]
                if pd.isna(pd_):
                    pd_ = inv.due_date.iloc[i]   # unknown date → assume paid on due date (flagged in decisions)
                pays.append({"payment_id": f"pay_{i+1:05d}", "invoice_id": iid, "client_id": cid, "pay_date": pd_, "amount": float(amt)})
        payments = pd.DataFrame(pays, columns=["payment_id", "invoice_id", "client_id", "pay_date", "amount"])
        # contracts
        ctr_path = IMPORT / e["contracts_file"]
        if ctr_path.exists():
            rawc = _read(ctr_path); cc = e["columns"]["contracts"]
            smap, rmap = e["status_map"], e["reason_map"]
            contracts = pd.DataFrame({
                "contract_id": rawc[cc["contract_id"]].astype(str),
                "client_id": rawc[cc["client_name"]].astype(str).str.strip().map(pseudonym),
                "start_date": _date(rawc[cc["start_date"]]) if cc.get("start_date") in rawc else pd.NaT,
                "status": rawc[cc["status"]].astype(str).str.lower().str.strip().map(lambda s: next((v for k, v in smap.items() if k in s), "active")),
                "status_date": _date(rawc[cc["status_date"]]) if cc.get("status_date") in rawc else pd.NaT,
                "suspend_reason": rawc[cc["suspend_reason"]].astype(str).str.lower().map(lambda s: next((v for k, v in rmap.items() if k in s), None)) if cc.get("suspend_reason") in rawc else None,
            })
        else:
            contracts = inv.drop_duplicates("client_id")[["client_id"]].assign(
                contract_id=lambda d: "ctr_" + d.client_id.str[-4:], start_date=inv.issue_date.min(),
                status="active", status_date=inv.issue_date.min(), suspend_reason=None)
        inv.drop_duplicates("client_id")[["client_id", "client_name"]].to_csv(IMPORT / "_aliases.csv", index=False)
        return Dataset(inv[["invoice_id", "client_id", "client_name", "contract_id", "issue_date", "due_date", "amount"]],
                       payments, contracts).validate()
