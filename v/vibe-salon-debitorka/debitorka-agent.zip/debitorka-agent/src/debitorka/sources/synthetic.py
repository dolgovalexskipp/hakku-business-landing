"""Synthetic dataset calibrated to the customer's real collection figures.

Real reference (Dec'25–May'26): ~330–360 invoices/month, 2.5–3.0 M ₽/month,
paid "on time" (by the 1st of month+2) 68–81 %, paid in total 77–86 %.
Invoices are issued on the last day of month; a small share are ad-hoc mid-month.
Two anomalies are planted near `as_of` so that alerts fire in the demo:
  * a cluster of mid-May invoices crossing the 90-day line on the last weekly snapshot,
  * 14 suspensions in the last week (norm 3–8), 8 of them "lost / not paying".
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from .base import Source
from ..schema import Dataset

MONTH_NAMES_RU = ["Январь", "Февраль", "Март", "Апрель", "Май", "Июнь", "Июль", "Август",
                  "Сентябрь", "Октябрь", "Ноябрь", "Декабрь"]


class SyntheticSource(Source):
    def __init__(self, cfg: dict, as_of: pd.Timestamp | None = None):
        super().__init__(cfg)
        self.s = cfg["synthetic"]
        self.terms = int(cfg.get("payment_terms_days", 2))
        self.as_of = pd.Timestamp(as_of) if as_of is not None else None

    def load(self) -> Dataset:
        s = self.s
        rng = np.random.default_rng(s["seed"])
        n_clients = s["clients"]
        start = pd.Timestamp(s["start_month"] + "-01")
        month_ends = [(start + pd.DateOffset(months=i)) + pd.offsets.MonthEnd(0) for i in range(s["months"])]
        as_of = self.as_of or (month_ends[-1] + pd.Timedelta(days=17))

        # --- clients & habits
        habits = s["habits"]
        names = list(habits)
        probs = np.array([habits[h]["share"] for h in names]); probs = probs / probs.sum()
        client_habit = rng.choice(names, size=n_clients, p=probs)
        client_ids = [f"client_{i:04d}" for i in range(1, n_clients + 1)]
        words = ["Ромашка", "Вектор", "Альфа", "Гранит", "Лотос", "Сфера", "Орион", "Титан", "Стимул", "Радуга"]
        client_names = [f"ООО {words[i % len(words)]}-{i+1:03d}" for i in range(n_clients)]
        client_start = start - pd.to_timedelta(rng.integers(0, 365 * 5, n_clients), unit="D")

        # --- contracts: one per client; statuses planted later
        contracts = pd.DataFrame({
            "contract_id": [f"ctr_{i:04d}" for i in range(1, n_clients + 1)],
            "client_id": client_ids, "start_date": client_start,
            "status": "active", "status_date": client_start, "suspend_reason": None,
        })

        # --- invoices
        inv_rows, pay_rows = [], []
        inv_n = pay_n = 0
        active_mask = np.ones(n_clients, dtype=bool)
        lo, hi = s["invoices_per_month"]
        for me in month_ends:
            if me > as_of:
                break
            k = int(rng.integers(lo, hi + 1))
            idx = rng.choice(np.where(active_mask)[0], size=min(k, active_mask.sum()), replace=False)
            # monthly "mood" factor shifts how many fast payers actually pay on time
            mood = rng.uniform(0.9, 1.1)
            for i in idx:
                issue = me
                if rng.random() < s["adhoc_share"]:
                    issue = me - pd.Timedelta(days=int(rng.integers(3, 27)))
                inv_n += 1
                amount = float(np.round(rng.lognormal(np.log(s["amount_mean"]) - s["amount_sigma"] ** 2 / 2,
                                                      s["amount_sigma"]), -1))
                amount = max(amount, 500.0)
                self._emit(inv_rows, pay_rows, inv_n, i, client_ids, client_names, issue, amount,
                           client_habit[i], habits, rng, mood, as_of)
        # anomaly: cluster of ad-hoc invoices crossing 90 days exactly on the last snapshot
        n_cluster = s["anomaly"]["stuck_cluster_invoices"]
        cluster_issue = as_of - pd.Timedelta(days=92 + self.terms)
        never_idx = np.where(client_habit == "never")[0]
        for i in rng.choice(never_idx, size=n_cluster, replace=False):
            inv_n += 1
            amount = float(np.round(rng.uniform(12000, 30000), -2))
            self._emit(inv_rows, pay_rows, inv_n, i, client_ids, client_names, cluster_issue, amount,
                       "never", habits, rng, 1.0, as_of)

        invoices = pd.DataFrame(inv_rows).drop(columns=["_paid_share"])
        payments = pd.DataFrame(pay_rows) if pay_rows else pd.DataFrame(
            columns=["payment_id", "invoice_id", "client_id", "pay_date", "amount"])

        # --- suspensions / terminations: weekly 3–8, last week = anomaly
        week_lo, week_hi = s["suspensions_per_week"]
        reasons = list(s["suspend_reasons"]); rp = np.array([s["suspend_reasons"][r] for r in reasons]); rp /= rp.sum()
        weeks_back = 16
        slow_ids = list(rng.permutation(np.where(np.isin(client_habit, ["never", "vslow", "slow"]))[0]))
        other_ids = list(rng.permutation(np.where(~np.isin(client_habit, ["never", "vslow", "slow"]))[0]))
        pool = other_ids + slow_ids          # pop() takes slow payers first, then others — never runs dry
        an = s["anomaly"]
        for w in range(weeks_back, -1, -1):
            week_end = as_of - pd.Timedelta(days=7 * w)
            if w == 0:
                n = an["suspensions_last_week"]; forced_lost = an["suspensions_last_week_lost"]
            else:
                n = int(rng.integers(week_lo, week_hi + 1)); forced_lost = 0
            for j in range(n):
                if not pool:
                    break
                i = pool.pop()
                reason = "lost" if j < forced_lost else rng.choice(reasons, p=rp)
                d = week_end - pd.Timedelta(days=int(rng.integers(0, 7)))
                contracts.loc[i, ["status", "status_date", "suspend_reason"]] = ["suspended", d, reason]
        # some older suspensions became terminations
        susp_old = contracts[(contracts.status == "suspended") & (contracts.status_date < as_of - pd.Timedelta(days=60))]
        for i in susp_old.sample(frac=0.5, random_state=int(s["seed"])).index:
            contracts.loc[i, ["status", "status_date"]] = ["terminated", contracts.loc[i, "status_date"] + pd.Timedelta(days=45)]
            contracts.loc[i, "suspend_reason"] = None
        return Dataset(invoices, payments, contracts).validate()

    def _emit(self, inv_rows, pay_rows, inv_n, i, client_ids, client_names, issue, amount, habit, habits,
              rng, mood, as_of):
        due = issue + pd.Timedelta(days=self.terms)
        inv_id = f"inv_{inv_n:05d}"
        inv_rows.append({"invoice_id": inv_id, "client_id": client_ids[i], "client_name": client_names[i],
                         "contract_id": f"ctr_{i+1:04d}", "issue_date": issue, "due_date": due,
                         "amount": amount, "_paid_share": 0.0})
        delay_rng = habits[habit]["delay"]
        if delay_rng is None:
            return
        d0, d1 = delay_rng
        delay = int(rng.integers(d0, d1 + 1))
        if habit == "fast" and rng.random() > mood * 0.97:  # occasionally a fast payer slips into 11–60
            delay = int(rng.integers(11, 45))
        pay_date = due + pd.Timedelta(days=delay)
        if pay_date > as_of:
            return
        # ~7 % partial payments: 40–80 % now, rest later (maybe after as_of)
        if rng.random() < 0.07:
            share = float(rng.uniform(0.4, 0.8))
            pay_rows.append({"payment_id": f"pay_{len(pay_rows)+1:05d}", "invoice_id": inv_id,
                             "client_id": client_ids[i], "pay_date": pay_date, "amount": round(amount * share, 2)})
            rest_date = pay_date + pd.Timedelta(days=int(rng.integers(7, 60)))
            if rest_date <= as_of:
                pay_rows.append({"payment_id": f"pay_{len(pay_rows)+1:05d}", "invoice_id": inv_id,
                                 "client_id": client_ids[i], "pay_date": rest_date, "amount": round(amount * (1 - share), 2)})
                inv_rows[-1]["_paid_share"] = 1.0
            else:
                inv_rows[-1]["_paid_share"] = share
        else:
            pay_rows.append({"payment_id": f"pay_{len(pay_rows)+1:05d}", "invoice_id": inv_id,
                             "client_id": client_ids[i], "pay_date": pay_date, "amount": amount})
            inv_rows[-1]["_paid_share"] = 1.0
