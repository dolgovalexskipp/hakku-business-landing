from __future__ import annotations
from abc import ABC, abstractmethod
from ..schema import Dataset


class Source(ABC):
    """Replaceable data layer: today xlsx export / synthetic, tomorrow 1C OData."""

    def __init__(self, cfg: dict):
        self.cfg = cfg

    @abstractmethod
    def load(self) -> Dataset: ...
