from .base import Source
from .synthetic import SyntheticSource
from .excel_1c import Excel1CSource


def get_source(name: str, cfg: dict) -> Source:
    if name == "synthetic":
        return SyntheticSource(cfg)
    if name == "excel":
        return Excel1CSource(cfg)
    if name == "odata":
        from .odata_1c import OData1CSource
        return OData1CSource(cfg)
    raise ValueError(f"unknown source {name}")
