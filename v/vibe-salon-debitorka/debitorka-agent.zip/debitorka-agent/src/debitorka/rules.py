"""Alert rules — thresholds from config.yaml. Input: metrics summary (+ stuck lists). Output: list[Alert]."""
from __future__ import annotations
from dataclasses import dataclass, field, asdict
import pandas as pd

LEVEL_ORDER = {"crit": 0, "warn": 1, "info": 2}
ICON = {"crit": "🔴", "warn": "🟠", "info": "🔵"}


def rub(x: float) -> str:
    return f"{x:,.0f} ₽".replace(",", " ")


@dataclass
class Alert:
    level: str            # info | warn | crit
    metric: str
    title: str
    value: float | int | None = None
    delta: float | None = None
    affected: list = field(default_factory=list)   # pseudonymous client ids + details
    explain: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


def _lvl(value, thr: dict, higher_is_bad=True):
    """Return crit/warn/None by comparing value with thresholds."""
    if value is None:
        return None
    if higher_is_bad:
        if value >= thr["crit"]:
            return "crit"
        if value >= thr["warn"]:
            return "warn"
    else:
        if value < thr["crit"]:
            return "crit"
        if value < thr["warn"]:
            return "warn"
    return None


def evaluate(summary: dict, stuck_now: pd.DataFrame, stuck_prev: pd.DataFrame, cfg: dict) -> list[Alert]:
    t = cfg["thresholds"]
    alerts: list[Alert] = []
    ov = summary["overdue"]

    # 1. overdue total delta
    tot = ov["Итого"]
    lvl = _lvl(tot["delta_28d_pct"], t["overdue_total_delta_pct"])
    if lvl:
        alerts.append(Alert(lvl, "overdue_total", f"Просрочка всего: {rub(tot['amount'])} ({tot['delta_28d_pct']:+.0f} % к тому же дню прошлого месяца)",
                            tot["amount"], tot["delta_28d_pct"],
                            explain="Сравнение с тем же днём прошлого месяца — недельная Δ искажена циклом выставления счетов"))

    # 2. 90+ bucket delta
    b90 = ov["90+"]
    lvl = _lvl(b90["delta_pct"], t["bucket_90plus_delta_pct"])
    if lvl:
        aff = summary.get("entered_90plus_week", [])
        ent_sum = sum(r["amount"] for r in aff); ent_inv = sum(r.get("invoices", 1) for r in aff)
        alerts.append(Alert(lvl, "aging_90plus",
                            f"90+ дней: {rub(b90['amount'])} ({b90['delta_pct']:+.0f} % к неделе), {b90['clients']} клиентов; "
                            f"за неделю перешли в 90+: {ent_inv} счетов на {rub(ent_sum)} ({len(aff)} клиентов)",
                            b90["amount"], b90["delta_pct"], affected=aff,
                            explain="Долги старше 90 дней — кандидаты на претензию/расторжение; ниже — кто пересёк 90 дней на этой неделе"))

    # 3. cohort below norm
    c = summary.get("cohort_last")
    if c and c.get("norm_pct") is not None:
        gap = c["norm_pct"] - c["pct"]
        lvl = _lvl(gap, t["cohort_below_norm_pp"])
        if lvl:
            alerts.append(Alert(lvl, "cohort", f"Когорта {c['month']}: {c['pct']:.0f} % оплачено на {c['week']}-й неделе при норме {c['norm_pct']:.0f} %",
                                c["pct"], -gap, explain="Кривая инкассации текущей когорты отстаёт от медианы прошлых месяцев"))

    # 4. KPI paid after month
    k = summary.get("kpi_last_closed")
    if k:
        lvl = _lvl(k["pct"], t["kpi_paid_after_month_pct"], higher_is_bad=False)
        if lvl:
            alerts.append(Alert(lvl, "kpi_month", f"KPI «оплата через месяц» по {k['month']}: {k['pct']:.1f} % (контроль {k['control_date']})",
                                k["pct"], explain="Доля оплаченной реализации месяца на контрольную дату ниже целевой"))

    # 5. suspensions
    s = summary["suspensions"]
    mean, sd, last = s["baseline_mean"], s["baseline_sd"], s["last_week"]
    lvl = None
    if sd > 0 and last > mean + t["suspensions_sigma"]["crit"] * sd or (mean > 0 and last > t["suspensions_ratio_crit"] * mean):
        lvl = "crit"
    elif sd > 0 and last > mean + t["suspensions_sigma"]["warn"] * sd:
        lvl = "warn"
    if lvl:
        br = s["by_reason_last_week"]
        alerts.append(Alert(lvl, "suspensions", f"Приостановок за неделю: {last} при норме {mean:.0f} ± {sd:.0f}",
                            last, last - mean,
                            explain=f"причины: потерялся/не платит {br['lost']}, спор {br['dispute']}, пауза {br['pause']}"))

    # 6. new stuck clients this week
    new_ids = sorted(set(stuck_now.client_id) - set(stuck_prev.client_id))
    if new_ids:
        n = len(new_ids)
        lvl = "warn" if n >= t["new_stuck_clients"]["warn"] else "info"
        rows = stuck_now[stuck_now.client_id.isin(new_ids)]
        aff = [{"client_id": r.client_id, "amount": float(r.amount), "max_age_days": int(r.max_age_days),
                "contract_status": r.contract_status} for r in rows.itertuples()]
        alerts.append(Alert(lvl, "new_stuck", f"Новых клиентов в 61+ дней за неделю: {n}", n, affected=aff,
                            explain="Впервые пересекли 61 день просрочки — связаться сейчас, пока не ушли в 90+"))

    alerts.sort(key=lambda a: LEVEL_ORDER[a.level])
    return alerts


def format_alerts_html(alerts: list[Alert], as_of: str, names: dict | None = None) -> str:
    """Telegram-ready HTML. `names` maps client_id->real name; pass None to keep pseudonyms."""
    if not alerts:
        return f"🟢 Дебиторка · срез {as_of}\nОтклонений нет, все показатели в норме."
    lines = [f"<b>Дебиторка · срез {as_of}</b>"]
    for a in alerts:
        lines.append(f"\n{ICON[a.level]} <b>{a.title}</b>")
        if a.explain:
            lines.append(f"<i>{a.explain}</i>")
        for r in a.affected[:5]:
            nm = (names or {}).get(r["client_id"], r["client_id"])
            st = {"terminated": "расторгнут", "suspended": "приостановлен", "active": "действует"}.get(r["contract_status"], "")
            lines.append(f"• {nm} · {rub(r['amount'])} · {r['max_age_days']} дн · {st}")
        if len(a.affected) > 5:
            lines.append(f"… ещё {len(a.affected) - 5} — см. витрину")
    return "\n".join(lines)
