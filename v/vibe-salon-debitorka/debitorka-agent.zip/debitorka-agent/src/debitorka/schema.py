"""Data contract: three flat tables. See docs/data_contract.md."""
from __future__ import annotations
from dataclasses import dataclass
import pandas as pd

INVOICE_COLS = ["invoice_id", "client_id", "client_name", "contract_id", "issue_date", "due_date", "amount"]
PAYMENT_COLS = ["payment_id", "invoice_id", "client_id", "pay_date", "amount"]
CONTRACT_COLS = ["contract_id", "client_id", "start_date", "status", "status_date", "suspend_reason"]
STATUSES = ("active", "suspended", "terminated")
REASONS = ("lost", "dispute", "pause")


@dataclass
class Dataset:
    invoices: pd.DataFrame
    payments: pd.DataFrame
    contracts: pd.DataFrame

    def validate(self) -> "Dataset":
        for df, cols, name in ((self.invoices, INVOICE_COLS, "invoices"),
                               (self.payments, PAYMENT_COLS, "payments"),
                               (self.contracts, CONTRACT_COLS, "contracts")):
            missing = [c for c in cols if c not in df.columns]
            if missing:
                raise ValueError(f"{name}: missing columns {missing}")
        for c in ("issue_date", "due_date"):
            self.invoices[c] = pd.to_datetime(self.invoices[c])
        self.payments["pay_date"] = pd.to_datetime(self.payments["pay_date"])
        for c in ("start_date", "status_date"):
            self.contracts[c] = pd.to_datetime(self.contracts[c])
        bad = set(self.contracts["status"]) - set(STATUSES)
        if bad:
            raise ValueError(f"contracts.status unknown values: {bad}")
        return self

    def aliases(self) -> dict[str, str]:
        """client_id -> client_name (stays local, never goes to LLM)."""
        return dict(self.invoices.drop_duplicates("client_id")[["client_id", "client_name"]].values)

    def save(self, folder) -> None:
        folder.mkdir(parents=True, exist_ok=True)
        self.invoices.to_csv(folder / "invoices.csv", index=False)
        self.payments.to_csv(folder / "payments.csv", index=False)
        self.contracts.to_csv(folder / "contracts.csv", index=False)

    @classmethod
    def load(cls, folder) -> "Dataset":
        return cls(pd.read_csv(folder / "invoices.csv"), pd.read_csv(folder / "payments.csv"),
                   pd.read_csv(folder / "contracts.csv")).validate()
