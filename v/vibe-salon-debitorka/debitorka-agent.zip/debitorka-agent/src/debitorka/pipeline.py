"""run(as_of): load → metrics → snapshot → rules → notify [→ digest]."""
from __future__ import annotations
import json
import pandas as pd
from .config import load_config, SNAPSHOTS, DATA
from .schema import Dataset
from .sources import get_source
from . import metrics as M
from .rules import evaluate, format_alerts_html, Alert
from .notify import get_notifier
from . import narrator


def load_dataset(source: str, cfg: dict, as_of: pd.Timestamp, cache: bool = True) -> Dataset:
    if source == "synthetic":
        folder = DATA / "synthetic"
        if cache and (folder / "invoices.csv").exists():
            return Dataset.load(folder)
        from .sources.synthetic import SyntheticSource
        ds = SyntheticSource(cfg, as_of=None).load()   # as_of fixed by config months → stable dataset
        ds.save(folder)
        return ds
    return get_source(source, cfg).load()


def snapshot(ds: Dataset, as_of: pd.Timestamp) -> dict:
    """Compute everything for one date and append to the cumulative logs in data/snapshots."""
    SNAPSHOTS.mkdir(parents=True, exist_ok=True)
    summ = M.summary(ds, as_of)
    prev = as_of - pd.Timedelta(days=7)
    stuck_now, stuck_prev = M.stuck_clients(ds, as_of), M.stuck_clients(ds, prev)
    # aging log (one row per bucket per date)
    ag = M.aging_delta(M.aging_buckets(ds, prev), M.aging_buckets(ds, as_of))
    ag.insert(0, "as_of", as_of.date().isoformat())
    _append(SNAPSHOTS / "aging.csv", ag, ["as_of", "bucket"])
    sw, _ = M.suspensions_weekly(ds, as_of, weeks=1)
    sw.insert(0, "as_of", as_of.date().isoformat())
    _append(SNAPSHOTS / "suspensions.csv", sw, ["as_of"])
    if summ["cohort_last"]:
        cc = M.cohort_curve(ds, summ["cohort_last"]["month"], as_of)
        _append(SNAPSHOTS / "cohorts.csv", cc, ["cohort", "week"])
    return {"summary": summ, "stuck_now": stuck_now, "stuck_prev": stuck_prev}


def run(as_of: str, source: str = "synthetic", notify: str = "console", digest: bool = False,
        real_names: bool = False, cfg: dict | None = None) -> list[Alert]:
    cfg = cfg or load_config()
    as_of_ts = pd.Timestamp(as_of)
    ds = load_dataset(source, cfg, as_of_ts)
    snap = snapshot(ds, as_of_ts)
    alerts = evaluate(snap["summary"], snap["stuck_now"], snap["stuck_prev"], cfg)
    names = ds.aliases() if real_names else None
    text = format_alerts_html(alerts, as_of, names)
    n = get_notifier(notify)
    n.send(text)
    if digest:
        n.send(narrator.weekly_digest(alerts, snap["summary"]))
    _append(SNAPSHOTS / "alerts.csv",
            pd.DataFrame([{"as_of": as_of, **{k: v for k, v in a.to_dict().items() if k != "affected"},
                           "affected": json.dumps(a.affected, ensure_ascii=False)} for a in alerts]),
            ["as_of", "metric"])
    return alerts


def backfill(start: str, end: str, every_days: int = 7, source: str = "synthetic", cfg: dict | None = None) -> None:
    cfg = cfg or load_config()
    ds = load_dataset(source, cfg, pd.Timestamp(end))
    for d in pd.date_range(pd.Timestamp(start), pd.Timestamp(end), freq=f"{every_days}D"):
        snapshot(ds, d)
        print(f"snapshot {d.date()} ok")


def _append(path, df: pd.DataFrame, keys: list[str]) -> None:
    if path.exists():
        old = pd.read_csv(path)
        df = pd.concat([old, df], ignore_index=True)
    if len(df):
        df = df.drop_duplicates(subset=keys, keep="last")
    df.to_csv(path, index=False)
