import re
from .base import Notifier


class ConsoleNotifier(Notifier):
    def send(self, text: str) -> bool:
        print("\n" + "=" * 60 + "\n" + re.sub(r"</?(b|i|code)>", "", text) + "\n" + "=" * 60)
        return True
