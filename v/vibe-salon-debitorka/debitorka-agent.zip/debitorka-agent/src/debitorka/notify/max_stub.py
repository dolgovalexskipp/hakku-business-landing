"""STUB — Max messenger (VK) bot notifier. Same interface as TelegramNotifier.
Next iteration: Max Bot API — see https://dev.max.ru (bot token, POST /messages?chat_id=...).
"""
from .base import Notifier


class MaxNotifier(Notifier):
    def send(self, text: str) -> bool:
        raise NotImplementedError("Max notifier is planned for the next iteration (docs/next.md)")
