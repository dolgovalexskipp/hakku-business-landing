"""Telegram Bot API notifier (HTML parse mode, chunked at 4000 chars)."""
from __future__ import annotations
import os
import requests
from .base import Notifier


class TelegramNotifier(Notifier):
    def __init__(self, token: str, chat_id: str):
        self.token, self.chat_id = token, chat_id

    @classmethod
    def from_env(cls) -> "TelegramNotifier":
        token, chat = os.environ.get("TELEGRAM_BOT_TOKEN"), os.environ.get("TELEGRAM_CHAT_ID")
        if not token or not chat:
            raise RuntimeError("TELEGRAM_BOT_TOKEN / TELEGRAM_CHAT_ID not set — use --notify console")
        return cls(token, chat)

    def send(self, text: str) -> bool:
        ok = True
        for chunk in _chunks(text, 4000):
            r = requests.post(f"https://api.telegram.org/bot{self.token}/sendMessage",
                              json={"chat_id": self.chat_id, "text": chunk, "parse_mode": "HTML",
                                    "disable_web_page_preview": True}, timeout=20)
            if r.status_code != 200:
                print(f"[telegram] {r.status_code}: {r.text[:200]}")
                ok = False
        return ok


def _chunks(text: str, n: int):
    while len(text) > n:
        cut = text.rfind("\n", 0, n)
        cut = cut if cut > 0 else n
        yield text[:cut]
        text = text[cut:]
    yield text
