from .base import Notifier
from .console import ConsoleNotifier
from .telegram import TelegramNotifier


def get_notifier(name: str) -> Notifier:
    if name == "console":
        return ConsoleNotifier()
    if name == "telegram":
        return TelegramNotifier.from_env()
    if name == "max":
        from .max_stub import MaxNotifier
        return MaxNotifier()
    raise ValueError(name)
