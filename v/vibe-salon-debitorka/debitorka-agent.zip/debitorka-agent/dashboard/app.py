"""Витрина руководителя — один файл Streamlit. Запуск: python3.11 -m streamlit run dashboard/app.py"""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

import json
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st
from debitorka import pipeline, metrics as M, narrator
from debitorka.config import load_config, SNAPSHOTS
from debitorka.rules import evaluate, ICON

st.set_page_config(page_title="Дебиторка — центр управления", layout="wide")
cfg = load_config()

with st.sidebar:
    st.title("Дебиторка")
    source = st.selectbox("Источник", ["synthetic", "excel"], index=0)
    as_of = pd.Timestamp(st.date_input("Дата среза", pd.Timestamp("2026-08-17").date()))
    real_names = st.toggle("Показывать реальные имена", value=True, help="Витрина локальная — имена никуда не уходят")
    st.caption("Алерты и LLM получают только псевдонимы client_XXXX")


@st.cache_data(show_spinner=False)
def _load(source, as_of_iso):
    return pipeline.load_dataset(source, cfg, pd.Timestamp(as_of_iso))


try:
    ds = _load(source, as_of.isoformat())
except Exception as e:
    st.error(f"Не удалось загрузить источник «{source}»: {e}")
    st.stop()

names = ds.aliases() if real_names else {}
nm = lambda cid: names.get(cid, cid)
summ = M.summary(ds, as_of)
stuck_now, stuck_prev = M.stuck_clients(ds, as_of), M.stuck_clients(ds, as_of - pd.Timedelta(days=7))
alerts = evaluate(summ, stuck_now, stuck_prev, cfg)
ov = summ["overdue"]

st.title("Центр управления дебиторкой")
st.caption(f"Срез {as_of.date()} · источник: {source} · счета выставляются последним днём месяца, срок оплаты {cfg['payment_terms_days']} дня")

# 1. светофор
c1, c2, c3, c4, c5 = st.columns(5)
def kcard(col, label, value, delta, good_when_down=True, suffix=""):
    col.metric(label, value, delta, delta_color="inverse" if good_when_down else "normal", help=suffix)
tot = ov["Итого"]
kcard(c1, "Просрочка итого", f"{tot['amount']/1e6:.2f} млн",
      None if tot["delta_28d_pct"] is None else f"{tot['delta_28d_pct']:+.0f} % к прошлому месяцу")
b90 = ov["90+"]
kcard(c2, "90+ дней", f"{b90['amount']/1e6:.2f} млн", None if b90["delta_pct"] is None else f"{b90['delta_pct']:+.0f} % к неделе")
k = summ["kpi_last_closed"]
kcard(c3, f"KPI {k['month'] if k else ''}", f"{k['pct']:.1f} %" if k else "—", None, good_when_down=False)
sp = summ["suspensions"]
kcard(c4, "Приостановки/нед", sp["last_week"], f"норма {sp['baseline_mean']:.0f} ± {sp['baseline_sd']:.0f}")
co = summ["cohort_last"]
kcard(c5, f"Когорта {co['month'] if co else ''}", f"{co['pct']:.0f} % на {co['week']}-й нед." if co else "—",
      (f"норма {co['norm_pct']:.0f} %" if co and co.get("norm_pct") else None), good_when_down=False)

# 7 (вверху, как лента) — алерты
st.subheader("Алерты")
if not alerts:
    st.success("Отклонений нет")
for a in alerts:
    with st.expander(f"{ICON[a.level]} {a.title}", expanded=(a.level == "crit")):
        st.write(a.explain)
        if a.affected:
            df = pd.DataFrame(a.affected); df.insert(0, "клиент", df.client_id.map(nm))
            st.dataframe(df.drop(columns=["client_id"]).rename(columns={"amount": "долг, ₽", "max_age_days": "дней", "contract_status": "договор"}),
                         hide_index=True, width="stretch")

left, right = st.columns(2)
# 2. собираемость
with left:
    st.subheader("Собираемость по месяцам")
    t = M.collection_table(ds, as_of)
    st.dataframe(t.drop(columns=["control_date", "control_reached"]).rename(columns={
        "month": "Месяц счёта", "invoices": "Счетов", "billed": "Выставлено ₽", "paid_in_time": "Оплачено в срок ₽",
        "pct_in_time": "% в срок", "paid_total": "Оплачено всего ₽", "pct_total": "% всего"}), hide_index=True, width="stretch")
# 3. бакеты по неделям
with right:
    st.subheader("Просрочка по срокам — недельные срезы")
    ag_path = SNAPSHOTS / "aging.csv"
    if ag_path.exists():
        ag = pd.read_csv(ag_path); ag = ag[ag.bucket != "Итого"]
        fig = px.bar(ag, x="as_of", y="amount", color="bucket", barmode="stack",
                     category_orders={"bucket": M.BUCKET_LABELS}, labels={"amount": "₽", "as_of": ""})
        fig.update_layout(height=320, margin=dict(l=0, r=0, t=10, b=0), legend_title="")
        st.plotly_chart(fig, width="stretch")
    else:
        st.info("Нет снимков — запустите backfill")
    cur = M.aging_buckets(ds, as_of)
    st.dataframe(cur.rename(columns={"bucket": "Бакет", "amount": "₽", "invoices": "Счетов", "clients": "Клиентов"}), hide_index=True, width="stretch")

left, right = st.columns(2)
# 4. когорты
with left:
    st.subheader("Кривые инкассации по когортам")
    months = sorted(ds.invoices[ds.invoices.issue_date <= as_of].issue_date.dt.to_period("M").unique())
    fig = go.Figure()
    for m in months[-6:]:
        c = M.cohort_curve(ds, str(m), as_of)
        if len(c):
            fig.add_trace(go.Scatter(x=c.week, y=c.pct, mode="lines+markers", name=str(m)))
    fig.update_layout(height=320, margin=dict(l=0, r=0, t=10, b=0), xaxis_title="неделя после конца месяца", yaxis_title="% оплачено по сумме")
    st.plotly_chart(fig, width="stretch")
# 5. приостановки
with right:
    st.subheader("Приостановки по неделям")
    sw, base = M.suspensions_weekly(ds, as_of)
    fig = px.bar(sw.melt(id_vars="week_end", value_vars=["lost", "dispute", "pause"], var_name="причина", value_name="шт"),
                 x="week_end", y="шт", color="причина", barmode="stack", labels={"week_end": ""})
    fig.add_hline(y=base["mean"], line_dash="dot", annotation_text=f"норма {base['mean']:.1f}")
    fig.update_layout(height=320, margin=dict(l=0, r=0, t=10, b=0))
    st.plotly_chart(fig, width="stretch")

# 6. зависшие
st.subheader("Зависшие клиенты (61+ дней)")
flt = st.multiselect("Статус договора", ["active", "suspended", "terminated"], default=["active", "suspended", "terminated"])
s = stuck_now[stuck_now.contract_status.isin(flt)].copy()
s.insert(0, "клиент", s.client_id.map(nm))
st.dataframe(s.drop(columns=["client_id", "client_name"]).rename(columns={"amount": "долг, ₽", "max_age_days": "макс. дней", "invoices": "счетов", "contract_status": "договор"}),
             hide_index=True, width="stretch", height=320)

# Q&A
st.subheader("Спросить агента")
q = st.text_input("Вопрос по данным (в LLM уходят только агрегаты и псевдонимы)", placeholder="кто в 90+ дольше всех? как идёт июльская когорта?")
if q:
    with st.spinner("думаю…"):
        st.write(narrator.ask(q, summ))
